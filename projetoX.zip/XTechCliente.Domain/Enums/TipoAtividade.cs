﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XTechCliente.Domain.Enums
{
    public enum TipoAtividade
    {
        CRIAÇÃO_DE_CLIENTE = 1,
        ATUALIZAR_DADOS = 2,
        EXCLUIR_CLIENTE = 3
    }
}
